# -*- coding: utf-8 -*-

import random
import numpy as np

INPUT = 1
OUTPUT = 2
HIDDEN = 3
BIAS = 4

def sigmoid(x):
    return 1.0/(1+ np.exp(-x))

class Synapse:
    def __init__(self, from_neuron, to_neuron):
        self.weight = random.random()
        self.fn = from_neuron
        self.tn = to_neuron

class Neuron:
    
    def getEstimatedValue(self):
        v = 0
    
        for synapse in self.in_syp:
            neuron = self.network.neurons[synapse.fn]
            
            #if neuron.estimated_value != -1:
            #    return neuron.estimated_value
            if neuron.value != -1:
                v = v + synapse.weight*(neuron.value)
            else:
                v = v + synapse.weight*(neuron.getEstimatedValue())
        
        #self.estimated_value = v
        
        return sigmoid(v)

    
    def __init__(self, id, ntype, ref, input_synapses, output_synapses, network):
        self.id = id
        self.type = ntype
        self.ref = ref
        self.in_syp = input_synapses
        self.out_syp = output_synapses

        if self.type == BIAS:
            self.value = 1
        else:
            self.value = -1;

        self.estimated_value = -1
        self.network = network