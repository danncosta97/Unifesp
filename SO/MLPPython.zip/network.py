# -*- coding: utf-8 -*-

from neuron import Neuron, Synapse, INPUT, OUTPUT, HIDDEN, BIAS, sigmoid

class NeuronInput:
    
    def __init__(self, id, ntype, ref=0):
        self.id = id
        self.type = ntype
        self.ref = ref

graph = {
    NeuronInput(1, INPUT, 0) : [3, 4],
    NeuronInput(2, INPUT, 1) : [3, 4],

    NeuronInput(3, BIAS) :   [6],
    NeuronInput(4, HIDDEN) : [6],
    NeuronInput(5, HIDDEN) : [6],

    NeuronInput(6, OUTPUT, 0) : []
}

class NeuralNetwork:
    
    def __init__(self, graph, inputs, outputs):
        self.neurons = {}
        self.inputs = inputs
        self.outputs = outputs
        
        for index in graph:
            self.neurons[index.id] = Neuron(index.id, index.type, index.ref, [], [], self)

            outs = []
            for i in range(len(graph[index])):
                sy = Synapse(index.id, graph[index][i])
                outs.append(sy)

            self.neurons[index.id].out_syp = outs

        for index in graph:
            for i in range(len(graph[index])):
                sy = Synapse(index.id, graph[index][i])
                self.neurons[graph[index][i]].in_syp.append(sy)
    
    def setInputData(self, data):
        for index in self.neurons:
            if self.neurons[index].type == INPUT:
                self.neurons[index].value = data[self.neurons[index].ref]
    
    def refreshNeurons(self):
        for index in self.neurons:
            self.neurons[index].estimated_value = -1

    def runEpoch(self):
        print("RUNNING EPOCH !")
        
        for i in range(len(self.inputs)):
            self.setInputData(self.inputs[i])
            
            #print(sigmoid(self.neurons[6].getEstimatedValue()))
            print(self.neurons[6].getEstimatedValue())
            
            self.refreshNeurons()
            
            

if __name__ == "__main__":
    inputs = [
        [0, 0],
        [0, 1],
        [1, 0],
        [1, 1]
    ]
    outputs = [
        [0],
        [1],
        [1],
        [0]
    ]
    nn = NeuralNetwork(graph, inputs, outputs)
    self = nn
    
    nn.runEpoch()