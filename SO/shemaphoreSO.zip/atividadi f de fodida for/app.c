#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>


sem_t A,B;


void *thread(void *arg){
  sem_wait(&A);
  sem_wait(&B);
  printf("Passou por A e B\n");
  sem_post(&A);
  sem_post(&B);
  pthread_exit(NULL);

}


int main(int argc, char const **argv) {

  sem_init(&A,0,1);
  sem_init(&B,0,1);
  pthread_t t1,t2;
  pthread_create(&t1, NULL, thread, NULL);
  pthread_create(&t2, NULL, thread, NULL);
  pthread_join(t1, NULL);
  pthread_join(t2, NULL);




  return 0;
}
