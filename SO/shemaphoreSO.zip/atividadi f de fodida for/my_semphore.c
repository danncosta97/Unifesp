
#define _GNU_SOURCE
#include <stdlib.h>
#include <dlfcn.h>
#include <stdio.h>
#include <semaphore.h>


int (*real_sem_wait)(sem_t *) = NULL;
int (*real_sem_post)(sem_t *) = NULL;

int sem_wait(sem_t *sem){         //quando o processo chamar o sem_wait, ele vai capturar a aplicacao e executar esse semwait

  if(!real_sem_wait){
    real_sem_wait = dlsym(RTLD_NEXT,"sem_wait");       //chamando a sem_wait original, aqui tera o tratamento previo
  }
  printf("Dentro da caralha da sem_wait(%p)...\n", sem);


/*  //qual o recurso em questão : semaforo
    //processo: pthread_self()

    insere_arco(G, p, r)  grafo G processo P requisitando R
    if(existe_ciclo(G)){ tem deadlock
      remove_arco(g,p,r);
      errno = X;
      return -1;
   }

   aqui pode prosseguir...
*/

   return(real_sem_wait(sem));

}


int sem_post(sem_t *sem){

  if(!real_sem_post){
    real_sem_post = dlsym(RTLD_NEXT,"sem_post");
  }

  printf("Dentro do sem_post\n");

  return(real_sem_post(sem));

}
