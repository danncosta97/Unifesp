import React, { Component } from 'react';
import { Text, View } from 'react-native';
import firebase from 'firebase';



const InitDB = () => {

  var config = {
    apiKey: "AIzaSyBITwjvNg6kmjeZtPoIP41SpByHoxuWkDo",
    authDomain: "banco-app-bd7aa.firebaseapp.com",
    databaseURL: "https://banco-app-bd7aa.firebaseio.com",
    projectId: "banco-app-bd7aa",
    storageBucket: "banco-app-bd7aa.appspot.com",
    messagingSenderId: "1096464858672"
  };
  firebase.initializeApp(config);

};

export default InitDB;
