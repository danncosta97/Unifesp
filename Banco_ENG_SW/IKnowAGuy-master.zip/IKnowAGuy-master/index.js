import { AppRegistry } from 'react-native';
import App from './App';
import { IKnowAGuy } from './app.json';

AppRegistry.registerComponent(IKnowAGuy, () => App);
