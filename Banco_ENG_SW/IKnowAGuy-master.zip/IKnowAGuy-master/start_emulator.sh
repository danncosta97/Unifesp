#!/bin/bash

cd ~/Android/Sdk/emulator
emulator -avd Nexus5X
