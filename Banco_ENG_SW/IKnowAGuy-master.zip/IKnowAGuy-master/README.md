# IKnowAGuy

---
- Install NPM
`sudo npm install`
- Install ESLint
`sudo npm install --save-dev eslint-config-rallycoding`
- Install React-Navigation
`sudo npm install --save react-navigation`
- Install Router-Flux
`sudo npm install --save react-native-router-flux`
- Install React-Native-IMEI
`sudo npm install react-native-imei --save | sudo react-native link react-native-imei`
- Install React-Native-Maps
`sudo npm install react-native-maps --save`
- Native-Maps Installation Guide
https://github.com/react-community/react-native-maps/blob/master/docs/installation.md
- Install Vector-Icons
`sudo npm install react-native-vector-icons --save | sudo react-native link react-native-vector-icons`
- Install Native-Base
`sudo npm install native-base`
---
