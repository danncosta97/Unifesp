import React, { Component } from 'react';
import {
    AppRegistry, StyleSheet,
    Text, View
} from 'react-native';

import Intro from './src/components/intro/intro.js';
import Rotas from './src/components/telas/rotas.js';

export default class IKnowAGuy extends Component {
    state = {
        currentScreen: 'rotas'
    };
    router(page) {
        this.setState({ currentScreen: page });
    }

    renderScreen() {
        const { currentScreen } = this.state;
        switch (currentScreen) {
            case 'intro':
                return <Intro router={this.router.bind(this)} />;
            case 'rotas':
                return <Rotas />;
            default:
                return <Text style={styles.errorText}>Ooopsss!</Text>;
        }
    }

    render() {
        return (
            <View style={styles.wrapper}>{this.renderScreen()}</View>
        );
    }
}

const styles = StyleSheet.create({
    wrapper: {
        flex: 1,
    },
    errorText: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'red'
    }
});

AppRegistry.registerComponent('IKnowAGuy', () => IKnowAGuy);
