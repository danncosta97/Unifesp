import React from 'react';
import { Text } from 'react-native';
import { StackNavigator } from 'react-navigation';

import Login from '../login/login.js';
import Cadastro from '../login/cadastro.js';
import Principal from './principal.js';
import drawer from './drawer.js';


const Rotas = StackNavigator({
    Login: { screen: Login },
    Cadastro: { screen: Cadastro },
    MenuPrincipal: { screen: Principal },
    Drawer: { screen: drawer }
});

export default Rotas;
