import React, { Component } from 'react';
import {
    Text, View, Alert,
    StyleSheet, TouchableOpacity
} from 'react-native';
import { Header, Left } from 'native-base';
import Ionicons from 'react-native-vector-icons/Ionicons';

const IMEI = require('react-native-imei');

class Principal extends Component {
    static navigationOptions = {
        drawerIcon: ({ tintColor }) => (
            <Ionicons name='md-home' style={{ fontSize: 24, color: tintColor }} />
        )
    }
    render() {
        return (
            <View >
                <Header style={{ backgroundColor: 'white' }} >
                    <Left>
                        <Ionicons
                            name='md-menu' onPress={() =>
                            this.props.navigation.openDrawer()}
                        />
                    </Left>
                </Header>
                <TouchableOpacity
                    style={styles.buttonContainer} onPress={() => { Actions.perfil(); }}
                >
                    <Text style={styles.buttonText}>Perfil</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.buttonContainer} onPress={() => { Actions.geoloc(); }}
                >
                    <Text style={styles.buttonText}>Geoloc</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.buttonContainer}
                    onPress={() => { Alert.alert(IMEI.getImei()); }}
                >
                    <Text style={styles.buttonText}>Imei</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.buttonContainer}
                    onPress={() => { Alert.alert('Deslogado com sucesso!'); }}
                >
                    <Text style={styles.buttonText}>Deslogar</Text>
                </TouchableOpacity>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    buttonContainer: {
        backgroundColor: '#2980b6',
        marginBottom: 10,
        paddingVertical: 15,
    },
    buttonText: {
        color: '#fff',
        textAlign: 'center',
        fontWeight: '700'
    }
});

export default Principal;
