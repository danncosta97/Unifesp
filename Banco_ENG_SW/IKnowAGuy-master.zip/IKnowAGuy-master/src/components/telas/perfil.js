import React, { Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';


export default class Perfil extends Component {
    render() {
        return (
          <View style={styles.container}>
            <Text style={styles.texto}>Ta no perfil!!!</Text>
          </View>
        );
    }
}

const styles = StyleSheet.create({
  container:{
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  texto:{
    fontSize: 20
  }
});
