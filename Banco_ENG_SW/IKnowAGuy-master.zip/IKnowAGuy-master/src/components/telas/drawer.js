import React, { Component } from 'react';
import {
    Platform, StyleSheet, Button,
    Text, View, SafeAreaView, Alert,
    ScrollView, Dimensions, Image
} from 'react-native';
import { createDrawerNavigator, DrawerItems } from 'react-navigation';

import Principal from './principal.js';
import perfil from './perfil.js';
import Geoloc from '../geoloc/geoloc.js';

const { width } = Dimensions.get('window');

const CustomDrawer = (props) => (
    <SafeAreaView style={{ flex: 1 }}>
        <View
            style={{ height: 150,
            backgroundColor: 'white',
            alignItems: 'center',
            justifyContent: 'center' }}
        >
            <Image
                source={require('../images/placeholder.png')}
                style={{ height: 100, width: 100, borderRadius: 50 }}
            />
            <Text style={{ fontSize: 18 }}> I Know a Guy! </Text>
        </View>
        <ScrollView>
            <DrawerItems {...props} />
        </ScrollView>
    </SafeAreaView>
);

const DrawerMenu = createDrawerNavigator({
    Home: Principal,
    Perfil: perfil,
    Mapa: Geoloc
}, {
    contentComponent: CustomDrawer,
    drawerWidth: width / 1.75,
    contentOptions: {
        activeTintColor: 'orange',
    }
});

class Drawer extends Component {
    static navigationOptions = {
        header: null,
        headerLeft: null,
    }
    render() {
        return (
            <DrawerMenu />
        );
    }
}

export default Drawer;
