import React, { Component } from 'react';
import {
    StyleSheet, Text,
    View, Animated
} from 'react-native';
import Loading from './loading.js';


class Intro extends Component {
    state = {
        springVal: new Animated.Value(0.8),
        fadeVal: new Animated.Value(1)
    };

    componentDidMount() {
        setTimeout(() => this.spring(), 2000);
    }

    spring() {
        Animated.sequence([
            Animated.spring(this.state.springVal, {
                toValue: 0.6,
                friction: 7,
                tension: 20
            }),
            Animated.parallel([
                Animated.spring(this.state.springVal, {
                    toValue: 17.5,
                    friction: 7,
                    tension: 5
                }),
                Animated.timing(this.state.fadeVal, {
                    toValue: 0,
                    duration: 200
                })
            ])
        ]).start(() => this.props.router('rotas'));
    }

    render() {
        return (
            <View style={styles.wrapper}>
                <View style={styles.center}>
                    <Animated.Text
                        style={{
                            opacity: this.state.fadeVal,
                            transform: [{ scale: this.state.springVal }] }}
                    >
                        <Text style={styles.introText}>I Know A Guy</Text>
                    </Animated.Text>
                    <Loading />
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    wrapper: {
        flex: 1,
        backgroundColor: '#2c3e50'
    },
    center: {
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center'
    },
    introText: {
        fontSize: 50,
        color: 'white',
        fontWeight: 'bold'
    }
});

export default Intro;
