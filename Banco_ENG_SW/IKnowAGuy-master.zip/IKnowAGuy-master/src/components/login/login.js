import React, { Component } from 'react';
import {
    View, Image, TextInput, StatusBar, TouchableOpacity,
    StyleSheet, KeyboardAvoidingView, Text
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

class Login extends Component {
    static navigationOptions = {
        header: null
    }
    render() {
        return (
            <KeyboardAvoidingView style={styles.container} >
                <View style={styles.loginContainer}>
                    <Image
                        resizeMode="contain" style={styles.logo}
                        source={require('../images/placeholder.png')}
                    />
                </View>
               <View style={styles.formContainer}>
               <StatusBar barStyle="light-content" />
                   <TextInput
                       style={styles.input}
                       autoCapitalize="none"
                       onSubmitEditing={() => this.passwordInput.focus()}
                       autoCorrect={false}
                       keyboardType='email-address'
                       returnKeyType="next"
                       placeholder='Usuário ou E-mail'
                       placeholderTextColor='rgba(225,225,225, 1)'
                   />

                   <TextInput
                       style={styles.input}
                       autoCapitalize="none"
                       returnKeyType="go" ref={(input) => this.passwordInput = input}
                       placeholder='Senha'
                       placeholderTextColor='rgba(225,225,225, 1)'
                       secureTextEntry
                   />

                   <TouchableOpacity
                        style={styles.buttonContainer}
                        onPress={() => { this.props.navigation.navigate('Drawer'); }}
                   >
                       <Text style={styles.buttonText}>Login</Text>
                   </TouchableOpacity>

                   <TouchableOpacity
                        style={styles.buttonContainer}
                        onPress={() => { this.props.navigation.navigate('Cadastro'); }}
                   >
                       <Text style={styles.buttonText}>Cadastre-se</Text>
                   </TouchableOpacity>
               </View>
            </KeyboardAvoidingView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#2c3e50',
    },
    loginContainer: {
        flexGrow: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    logo: {
        position: 'absolute',
        width: 300,
        height: 100
    },
    formContainer: {
        padding: 20,
        backgroundColor: 'rgba(225,225,225,0.1)',
        marginRight: 15,
        marginLeft: 15,
        marginTop: 10,
        marginBottom: 10,
        paddingBottom: 0,
        borderRadius: 10,
        borderWidth: 1,
    },
    input: {
        height: 40,
        backgroundColor: 'rgba(225,225,225,0.2)',
        marginBottom: 10,
        padding: 10,
        color: '#fff',
    },
    buttonContainer: {
        backgroundColor: '#2980b6',
        marginBottom: 10,
        paddingVertical: 15,
    },
    buttonText: {
        color: '#fff',
        textAlign: 'center',
        fontWeight: '700'
    },
    loginButton: {
        backgroundColor: '#2980b6',
        color: '#fff'
    }
});

export default Login;
