import React, { Component } from 'react';
import {
    StyleSheet, Alert,
    Text, View, KeyboardAvoidingView,
    TextInput, StatusBar, TouchableOpacity
} from 'react-native';

const cadastrando = () => {
  Alert.alert('Cadastrado!');
};

export default class Cadastro extends Component {
    static navigationOptions = {
        header: null,
        headerLeft: null,
    }
    render() {
        return (
            <KeyboardAvoidingView style={styles.container}>
                <View style={styles.formContainer}>
                    <View style={{ padding: 20 }}>
                        <StatusBar barStyle="light-content" />
                            <TextInput
                                style={styles.input}
                                autoCapitalize="none"
                                onSubmitEditing={() => this.passwordInput.focus()}
                                autoCorrect={false}
                                keyboardType='email-address'
                                returnKeyType="next"
                                placeholder='Nome Completo'
                                placeholderTextColor='rgba(225,225,225, 1)'
                            />

                            <TextInput
                                style={styles.input}
                                autoCapitalize="none"
                                autoCorrect={false}
                                keyboardType='email-address'
                                returnKeyType="next"
                                placeholder='Usuário'
                                placeholderTextColor='rgba(225,225,225, 1)'
                            />

                            <TextInput
                                style={styles.input}
                                autoCapitalize="none"
                                autoCorrect={false}
                                keyboardType='email-address'
                                returnKeyType="next"
                                placeholder='E-mail'
                                placeholderTextColor='rgba(225,225,225, 1)'
                            />

                            <TextInput
                                style={styles.input}
                                autoCapitalize="none"
                                returnKeyType="go" ref={(input) => this.passwordInput = input}
                                placeholder='Senha'
                                placeholderTextColor='rgba(225,225,225, 1)'
                                secureTextEntry
                            />

                            <TouchableOpacity
                                style={styles.buttonContainer}
                                onPress={() => { cadastrando(); }}
                            >
                                <Text style={styles.buttonText}>Cadastrar</Text>
                            </TouchableOpacity>
                       </View>
                </View>
             </KeyboardAvoidingView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: '#2c3e50',
    },
    formContainer: {
        backgroundColor: 'rgba(225,225,225,0.1)',
        marginRight: 15,
        marginLeft: 15,
        marginTop: 10,
        marginBottom: 10,
        borderRadius: 10,
        borderWidth: 1,
    },
    input: {
        height: 40,
        backgroundColor: 'rgba(225,225,225,0.2)',
        marginBottom: 10,
        padding: 10,
        color: '#fff',
    },
    buttonContainer: {
        backgroundColor: '#2980b6',
        marginBottom: 10,
        paddingVertical: 15,
    },
    buttonText: {
        color: '#fff',
        textAlign: 'center',
        fontWeight: '700'
    },
    loginButton: {
        backgroundColor: '#2980b6',
        color: '#fff'
    }
});
