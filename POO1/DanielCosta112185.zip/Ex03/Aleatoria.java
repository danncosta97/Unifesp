package Ex03;

public class Aleatoria {
	public Aleatoria(){
		
	}
	
	public void testa() throws Erro{
		throw new Erro("Dados Errados");
	}
}
