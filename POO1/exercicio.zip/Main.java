
package exercicio;

public class Main {
	
	public static void main(String[] args){
		Comparable[] c = {new Coisa(1),new Coisa(5),new Coisa(3),new Coisa(9)};
	
		Ordena.ordena(c);
				
	}
	
	
}
