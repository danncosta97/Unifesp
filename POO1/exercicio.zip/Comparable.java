package exercicio;

public interface Comparable {
	int compareTo(Comparable x1);
}
