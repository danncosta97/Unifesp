<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <title>MySQL Test</title>

  </head>

  <body>
    <h1>Testing MySQL connection</h1> <br>
    <?php
      require('connectionDB.php');
     ?>
  </body>

</html>
